<?PHP
class Homemodel extends CI_Model
{
	
}
?>